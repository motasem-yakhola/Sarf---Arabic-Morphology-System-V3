package sarf.gerund.trilateral.augmented;

/**
 * <p>Title: Sarf Program</p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: ALEXO</p>
 *
 * @author Haytham Mohtasseb Billah
 * @version 1.0
 */
public interface TrilateralAugmentedGerundConjugatorListener {
    public int selectPatternFormNo(int formulaNo);
}
