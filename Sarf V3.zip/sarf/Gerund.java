package sarf;

/**
 * <p>Title: </p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class Gerund {
    private String symbol;
    private String value;

    public Gerund() {
    }

    public String getSymbol() {
        return symbol;
    }

    public String getValue() {
        return value;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
